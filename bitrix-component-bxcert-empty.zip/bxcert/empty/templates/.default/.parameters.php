<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();
$arTemplateParameters = array(
	"BXCERT_COUNT_ELEMENTS" => array(
		"NAME" => GetMessage("BXCERT_COUNT_ELEMENTS"),
		"TYPE" => "STRING",
		"DEFAULT" => "4",
	)
);
?>